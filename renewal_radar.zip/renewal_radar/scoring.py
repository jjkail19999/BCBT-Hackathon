"""Transparent, rules-based risk score (0-100). Every point can be traced to a component."""
import datetime as dt
from statistics import mean

import db
from taxonomy import SIGNAL_TYPES


def clamp(x, lo, hi):
    return max(lo, min(hi, x))


def band(score):
    return "High" if score >= 50 else "Medium" if score >= 25 else "Low"


def score_account(sub, usage, signals, today=None):
    today = today or dt.date.today()
    days = (dt.date.fromisoformat(sub["renewal_date"]) - today).days
    recent, baseline = mean(usage[-14:]), mean(usage[:45]) or 1
    usage_pct = (recent - baseline) / baseline
    seat_pct = (sub["seats_prev"] - sub["seats"]) / sub["seats_prev"] if sub["seats_prev"] else 0

    usage_pts = clamp(-usage_pct * 100, 0, 30)                     # 30% drop -> 30 pts
    seat_pts = clamp(seat_pct * 100, 0, 15)                        # 15% seat cut -> 15 pts
    signal_pts = clamp(sum(SIGNAL_TYPES[s["signal_type"]]["weight"] * s["confidence"] for s in signals), 0, 45)
    base = usage_pts + seat_pts + signal_pts
    urgency_pts = min(10, base * 0.25) if days <= 30 else min(5, base * 0.12) if days <= 60 else 0
    total = round(clamp(base + urgency_pts, 0, 100))
    return {
        "score": total, "band": band(total), "days_to_renewal": days,
        "usage_pct": usage_pct, "seat_pct": seat_pct,
        "components": {"Usage drop": round(usage_pts), "Seat cut": round(seat_pts),
                       "Call signals": round(signal_pts), "Renewal soon": round(urgency_pts)},
    }


def score_all(con=None, window_days=None):
    con = con or db.connect()
    rows = con.execute("SELECT a.*, s.* FROM accounts a JOIN subscriptions s ON s.account_id=a.id").fetchall()
    out = []
    for r in rows:
        usage = [u[0] for u in con.execute(
            "SELECT active_users FROM usage WHERE account_id=? ORDER BY day", (r["id"],))]
        sigs = [dict(s) for s in con.execute(
            "SELECT s.*, c.call_date, c.title FROM signals s JOIN calls c ON c.id=s.call_id "
            "WHERE s.account_id=? ORDER BY c.call_date DESC", (r["id"],))]
        sc = score_account(r, usage, sigs)
        if window_days is not None and not (0 <= sc["days_to_renewal"] <= window_days):
            continue
        out.append({**dict(r), **sc, "signals": sigs, "arr": r["mrr"] * 12})
    return sorted(out, key=lambda x: (-x["score"], x["days_to_renewal"]))
