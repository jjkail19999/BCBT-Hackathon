"""Accuracy check against the planted ground truth (matched per call and signal type)."""
import db
from taxonomy import LABELS


def evaluate(con=None):
    con = con or db.connect()
    truth = {(r[0], r[1]) for r in con.execute("SELECT call_id, signal_type FROM planted WHERE is_distractor=0")}
    decoys = {(r[0], r[1]) for r in con.execute("SELECT call_id, signal_type FROM planted WHERE is_distractor=1")}
    pred_rows = {(r["call_id"], r["signal_type"]): r for r in con.execute("SELECT * FROM signals")}
    pred = set(pred_rows)
    tp, fp, fn = truth & pred, pred - truth, truth - pred
    precision = len(tp) / len(pred) if pred else 0.0
    recall = len(tp) / len(truth) if truth else 0.0
    f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0

    per_type = []
    for t, label in LABELS.items():
        tr = {x for x in truth if x[1] == t}
        pr = {x for x in pred if x[1] == t}
        per_type.append({"Signal": label, "Planted": len(tr), "Found": len(tr & pr),
                         "False alarms": len(pr - tr)})
    planted_lines = {(r[0], r[1]): r[2] for r in con.execute("SELECT call_id, signal_type, line FROM planted")}
    misses = [{"Call": c, "Signal": LABELS[t], "Planted line": planted_lines[(c, t)]} for c, t in sorted(fn)]
    false_alarms = [{"Call": c, "Signal": LABELS[t], "Flagged quote": pred_rows[(c, t)]["quote"],
                     "Was a decoy": (c, t) in decoys} for c, t in sorted(fp)]
    n_calls = con.execute("SELECT COUNT(*) FROM calls").fetchone()[0]
    source = con.execute("SELECT source FROM signals GROUP BY source ORDER BY COUNT(*) DESC LIMIT 1").fetchone()
    return {"precision": precision, "recall": recall, "f1": f1, "planted": len(truth), "found": len(tp),
            "false_alarms": len(fp), "decoys": len(decoys), "decoys_resisted": len(decoys - pred),
            "calls": n_calls, "per_type": per_type, "misses": misses, "false_alarm_rows": false_alarms,
            "source": source[0] if source else "none"}


if __name__ == "__main__":
    r = evaluate()
    print(f"[{r['source']}] precision {r['precision']:.0%}  recall {r['recall']:.0%}  F1 {r['f1']:.0%}  "
          f"({r['found']}/{r['planted']} found, {r['false_alarms']} false alarms, "
          f"{r['decoys_resisted']}/{r['decoys']} decoys resisted)")
