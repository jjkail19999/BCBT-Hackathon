# Renewal Radar (working title)

Ranked renewal-risk list for a CSM; every flag links to the call quote or usage change behind it.
Synthetic data only; all companies and people are fictional.

## Run
```bash
pip install -r requirements.txt
cp .env.example .env                  # then paste the team's OpenRouter key into .env (never commit it)
python pipeline.py                    # generate data -> extract signals -> score -> briefs -> accuracy
python pipeline.py --llm-transcripts  # same, but the LLM writes natural transcripts around the planted lines
streamlit run app.py
```
Without a key in `.env` everything runs offline (keyword rules + template briefs). `MOCK_LLM=1` forces offline mode.
The model is set in `.env` (`LLM_MODEL`, default `~anthropic/claude-sonnet-latest` via OpenRouter).

## Files
| File | What it does |
|---|---|
| `taxonomy.py` | The 6 signal types, their weights, definitions (prompt) and next steps |
| `data_gen.py` | 30 accounts, subscriptions, 90 days usage, ~60 calls; plants signals + decoys as ground truth |
| `extract.py` | LLM structured extraction; drops any quote not found verbatim in a customer turn |
| `scoring.py` | Transparent 0-100 score: usage drop (30) + seat cut (15) + signals (45) + renewal soon (10) |
| `brief.py` | Brief that may cite only numbered evidence; uncited sentences fail validation -> template |
| `evaluate.py` | Precision / recall / decoys resisted vs. planted ground truth |
| `app.py` | The one screen + "Is the AI right?" tab |

## Demo tip
Run once with `MOCK_LLM=1` (keyword baseline falls for every decoy) and once with the LLM, and show both
accuracy numbers side by side. That's the "evidence our AI is correct" moment.
