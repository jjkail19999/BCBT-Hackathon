"""One command for the whole thing: python pipeline.py [--llm-transcripts]"""
import argparse

import brief
import data_gen
import evaluate
import extract
import llm

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--seed", type=int, default=7)
    ap.add_argument("--llm-transcripts", action="store_true")
    a = ap.parse_args()
    con = data_gen.generate(a.seed, a.llm_transcripts)
    extract.run(con)
    brief.run_all(con)
    r = evaluate.evaluate(con)
    print(f"Accuracy [{r['source']}]: precision {r['precision']:.0%}, recall {r['recall']:.0%}, "
          f"{r['decoys_resisted']}/{r['decoys']} decoys resisted")
    if llm.USAGE["calls"]:
        print("Usage:", llm.usage_summary())
