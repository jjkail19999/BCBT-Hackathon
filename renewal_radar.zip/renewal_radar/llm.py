"""Thin LLM wrapper. Talks to OpenRouter (OpenAI-compatible API) using the key in .env.
Without a key (or with MOCK_LLM=1) everything falls back to rules, so the app always runs offline."""
import json
import os
import re
import threading
from pathlib import Path

try:
    from dotenv import load_dotenv
    load_dotenv(Path(__file__).parent / ".env")
except ImportError:  # python-dotenv not installed: rely on exported env vars
    pass

BASE_URL = os.getenv("LLM_BASE_URL", "https://openrouter.ai/api/v1")
MODEL = os.getenv("LLM_MODEL", "~anthropic/claude-sonnet-latest")
_client = None
_lock = threading.Lock()
USAGE = {"calls": 0, "prompt_tokens": 0, "completion_tokens": 0}


def api_key():
    return os.getenv("OPENROUTER_API_KEY") or os.getenv("OPENAI_API_KEY")


def enabled() -> bool:
    return bool(api_key()) and os.getenv("MOCK_LLM") != "1"


def client():
    global _client
    if _client is None:
        from openai import OpenAI
        _client = OpenAI(api_key=api_key(), base_url=BASE_URL)
    return _client


def _track(resp):
    u = getattr(resp, "usage", None)
    with _lock:
        USAGE["calls"] += 1
        if u:
            USAGE["prompt_tokens"] += u.prompt_tokens or 0
            USAGE["completion_tokens"] += u.completion_tokens or 0


def _parse_json(text: str) -> dict:
    text = text.strip()
    text = re.sub(r"^```(?:json)?\s*|\s*```$", "", text)
    start, end = text.find("{"), text.rfind("}")
    return json.loads(text[start:end + 1])


def chat_json(system: str, user: str, schema: dict, name: str, temperature: float = 0.0) -> dict:
    """Ask for JSON matching `schema`. Tries native structured output first; if the model/provider
    rejects it, falls back to putting the schema in the prompt and parsing the reply."""
    messages = [{"role": "system", "content": system}, {"role": "user", "content": user}]
    try:
        resp = client().chat.completions.create(
            model=MODEL, temperature=temperature, messages=messages, max_tokens=1500,
            response_format={"type": "json_schema", "json_schema": {"name": name, "strict": True, "schema": schema}},
        )
        _track(resp)
        return _parse_json(resp.choices[0].message.content)
    except Exception:  # noqa: BLE001
        messages[0]["content"] = (system + "\n\nReply with ONLY a JSON object matching this JSON schema, "
                                  "no prose, no code fences:\n" + json.dumps(schema))
        resp = client().chat.completions.create(model=MODEL, temperature=temperature,
                                                messages=messages, max_tokens=1500)
        _track(resp)
        return _parse_json(resp.choices[0].message.content)


def chat_text(system: str, user: str, temperature: float = 0.8) -> str:
    resp = client().chat.completions.create(
        model=MODEL, temperature=temperature, max_tokens=2500,
        messages=[{"role": "system", "content": system}, {"role": "user", "content": user}],
    )
    _track(resp)
    return resp.choices[0].message.content


def usage_summary() -> str:
    return (f"{USAGE['calls']} LLM calls, {USAGE['prompt_tokens']:,} input + "
            f"{USAGE['completion_tokens']:,} output tokens")
