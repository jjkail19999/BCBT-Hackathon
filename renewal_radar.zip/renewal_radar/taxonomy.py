"""Fixed signal taxonomy. Weights feed the risk score; definitions feed the LLM prompt."""

SIGNAL_TYPES = {
    "champion_departure": {
        "label": "Champion leaving",
        "weight": 18,
        "definition": "The main customer contact or sponsor says they are leaving the company, "
                      "changing roles, or handing the account to someone else.",
        "next_step": "Get an intro to the successor this week and re-run the value story with them.",
    },
    "competitor_mention": {
        "label": "Competitor evaluation",
        "weight": 15,
        "definition": "The customer is currently evaluating, trialing, or being asked to look at a "
                      "competing product. Past evaluations that were already decided in our favour do not count.",
        "next_step": "Ask what triggered the evaluation and offer a side-by-side on the features they use most.",
    },
    "pricing_complaint": {
        "label": "Pricing pushback",
        "weight": 12,
        "definition": "The customer currently says the price is too high, questions value for money, "
                      "or signals they will ask for a discount at renewal. Resolved past discussions do not count.",
        "next_step": "Prepare a usage-based value summary and a right-sized seat option before the renewal call.",
    },
    "budget_cut": {
        "label": "Budget pressure",
        "weight": 14,
        "definition": "The customer mentions budget cuts, spending freezes, layoffs, or a procurement "
                      "review that puts this tool at risk.",
        "next_step": "Find out who signs off in procurement and get the renewal on their list early.",
    },
    "low_adoption": {
        "label": "Low adoption",
        "weight": 10,
        "definition": "The customer says the team isn't using the product, stopped using it, rolled it "
                      "back, or can't get value from it.",
        "next_step": "Offer a 30-minute re-onboarding for the team that dropped off.",
    },
    "exec_disengagement": {
        "label": "Exec disengaged",
        "weight": 11,
        "definition": "An executive sponsor stopped attending or responding, or leadership says the tool "
                      "is no longer a priority.",
        "next_step": "Ask your own leadership to reach out exec-to-exec before the renewal.",
    },
}

LABELS = {k: v["label"] for k, v in SIGNAL_TYPES.items()}
