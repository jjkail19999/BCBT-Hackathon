"""Signal extraction. LLM with structured output; every quote must be found verbatim in the
transcript and spoken by the customer, otherwise it is dropped (no ungrounded flags)."""
import re
from concurrent.futures import ThreadPoolExecutor

import db
import llm
from taxonomy import SIGNAL_TYPES

LINE_RE = re.compile(r"^(?P<name>[^()\n]+?) \((?P<label>[^)\n]+)\):\s*(?P<text>.+)$")

SCHEMA = {
    "type": "object", "additionalProperties": False, "required": ["signals"],
    "properties": {"signals": {"type": "array", "items": {
        "type": "object", "additionalProperties": False,
        "required": ["signal_type", "speaker", "confidence", "quote"],
        "properties": {
            "signal_type": {"type": "string", "enum": list(SIGNAL_TYPES)},
            "speaker": {"type": "string"},
            "confidence": {"type": "number"},
            "quote": {"type": "string"},
        }}}},
}

SYSTEM = (
    "You review customer success call transcripts and extract renewal-risk signals.\n"
    "Signal types (use only these):\n"
    + "\n".join(f"- {k}: {v['definition']}" for k, v in SIGNAL_TYPES.items())
    + "\n\nRules:\n"
    "- Only statements by the CUSTOMER count, never the vendor's CSM.\n"
    "- The quote must be copied verbatim from a single turn: the shortest full sentence(s) that prove the signal.\n"
    "- Only current risks. Past issues that were resolved, or comparisons already decided in the vendor's favour, are NOT signals.\n"
    "- confidence is 0-1. Return an empty list if there are no signals. At most one entry per signal type."
)

RULES = {  # offline fallback: deliberately naive keyword rules (shows why the LLM + eval matter)
    "champion_departure": r"\b(leaving|last day|take over|taking over|left)\b",
    "competitor_mention": r"\b(vantora|cleversuite|flowbird)\b",
    "pricing_complaint": r"\b(price|pricing|discount|steep|expensive)\b",
    "budget_cut": r"\b(budgets?|freeze|layoffs?|procurement)\b",
    "low_adoption": r"(stopped logging in|nobody (really )?uses|not using|went back to)",
    "exec_disengagement": r"(stopped responding|not a priority|isn't a priority|anyone senior)",
}


def norm(s: str) -> str:
    return re.sub(r"\s+", " ", s.strip().strip("\"'“”").lower())


def parse_turns(transcript: str):
    turns = []
    for line in transcript.splitlines():
        m = LINE_RE.match(line.strip())
        if m:
            turns.append({"name": m["name"].strip(), "label": m["label"], "text": m["text"],
                          "is_csm": "CSM" in m["label"]})
    return turns


def ground(raw, turns):
    """Keep only signals whose quote appears verbatim in one customer turn; fix the speaker from the transcript."""
    out, seen = [], set()
    for s in raw:
        q = norm(s["quote"])
        if len(q) < 8 or s["signal_type"] in seen:
            continue
        turn = next((t for t in turns if q in norm(t["text"])), None)
        if turn is None or turn["is_csm"]:
            continue
        # store the quote exactly as written in the transcript
        start = norm(turn["text"]).find(q)
        exact = re.sub(r"\s+", " ", turn["text"].strip())[start:start + len(q)]
        seen.add(s["signal_type"])
        out.append({"signal_type": s["signal_type"], "speaker": turn["name"],
                    "confidence": max(0.0, min(1.0, float(s["confidence"]))), "quote": exact})
    return out


def extract_rules(transcript: str):
    turns = parse_turns(transcript)
    raw = []
    for t in turns:
        if t["is_csm"]:
            continue
        for stype, pat in RULES.items():
            if re.search(pat, t["text"], re.I):
                raw.append({"signal_type": stype, "speaker": t["name"], "confidence": 0.6, "quote": t["text"]})
    return ground(raw, turns)


def extract_llm(transcript: str):
    data = llm.chat_json(SYSTEM, transcript, SCHEMA, "risk_signals")
    return ground(data["signals"], parse_turns(transcript))


def run(con=None, use_llm=None, workers=8):
    con = con or db.connect()
    use_llm = llm.enabled() if use_llm is None else use_llm
    calls = con.execute("SELECT id, account_id, transcript FROM calls").fetchall()
    fn = extract_llm if use_llm else extract_rules

    def work(c):
        try:
            return c, fn(c["transcript"]), "llm" if use_llm else "rules"
        except Exception as e:  # noqa: BLE001
            print(f"call {c['id']}: LLM failed ({e}); using rules")
            return c, extract_rules(c["transcript"]), "rules"

    con.execute("DELETE FROM signals")
    with ThreadPoolExecutor(max_workers=workers if use_llm else 1) as pool:
        for c, sigs, src in pool.map(work, calls):
            for s in sigs:
                con.execute("INSERT INTO signals (call_id, account_id, signal_type, speaker, confidence, quote, source)"
                            " VALUES (?,?,?,?,?,?,?)",
                            (c["id"], c["account_id"], s["signal_type"], s["speaker"], s["confidence"], s["quote"], src))
    con.commit()
    n = con.execute("SELECT COUNT(*) FROM signals").fetchone()[0]
    print(f"Extracted {n} signals from {len(calls)} calls using {'LLM (' + llm.MODEL + ')' if use_llm else 'rules'}.")
    return con


if __name__ == "__main__":
    run()
