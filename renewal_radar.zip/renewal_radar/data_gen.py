"""Synthetic dataset: 30 fictional accounts, subscriptions, 90 days of usage, ~60 call transcripts.

Risk signals are PLANTED as exact customer lines and recorded in the `planted` table, so we can
measure extraction accuracy later. Distractors are look-alike lines that are NOT risks
(e.g. "we looked at a competitor last year and picked you") to test that the AI isn't just keyword matching.
"""
import argparse
import datetime as dt
import random
from concurrent.futures import ThreadPoolExecutor

import db
import llm
from taxonomy import SIGNAL_TYPES

VENDOR = "Brightdesk"          # the fictional SaaS company our CSM works for
CSM = "Lena Vogt"
COMPETITORS = ["Vantora", "Cleversuite", "Flowbird"]   # fictional competitors

COMPANIES = [
    "Alpenquell Getränke", "Brandt & Sohn Maschinenbau", "Celsia Health", "Dunewood Retail",
    "Elbtal Energie", "Fernweh Reisen", "Glasblau Studios", "Hafenkante Foods", "Isarwerk Software",
    "Juniper Lane Interiors", "Kieselstein Bau", "Lindgrün Organics", "Mondschein Hotels",
    "Nordlicht Logistik", "Oberhaus Legal", "Pixelhain Games", "Quellgrund Water", "Rotfuchs Mobility",
    "Sandkorn Education", "Tannenhof Pharma", "Uferwerk Events", "Vierkant Architects",
    "Weißdorn Insurance", "Xantis Robotics", "Ysenburg Wines", "Zinnober Fashion", "Ackerland AgriTech",
    "Bergwind Outdoor", "Cobalt Harbour Finance", "Distelfink Marketing",
]
INDUSTRIES = ["Logistics", "Retail", "Healthcare", "Manufacturing", "Software", "Hospitality",
              "Energy", "Professional services", "Education", "Finance"]
FIRST = ["Jonas", "Mia", "Felix", "Sara", "Lukas", "Hannah", "Emre", "Clara", "Tobias", "Nina",
         "David", "Lea", "Paul", "Amira", "Jan", "Sophie", "Can", "Julia"]
LAST = ["Weber", "Schmidt", "Kaya", "Hoffmann", "Becker", "Novak", "Schulz", "Lange", "Krause",
        "Meyer", "Fischer", "Wolf", "Yilmaz", "Brandt"]
ROLES = ["Head of Operations", "Customer Support Lead", "Marketing Manager", "Ops Manager",
         "Head of Sales", "Team Lead"]

SIGNAL_LINES = {
    "champion_departure": [
        "Before we start, I should tell you I'm leaving {co} at the end of next month. {nxt} will take over the account from our side.",
        "Quick heads-up: my last day here is in three weeks, and honestly I don't know who will own this tool after me.",
    ],
    "competitor_mention": [
        "To be transparent, our new VP asked us to look at {comp} before we sign anything again.",
        "We have a trial of {comp} running with two of our team leads right now.",
    ],
    "pricing_complaint": [
        "Honestly, the renewal quote feels steep for what we're actually using. We'd need a real discount to justify it.",
        "Finance flagged that we're paying for {seats} seats and the price went up again. That's going to be a hard conversation.",
    ],
    "budget_cut": [
        "We're under a spending freeze until Q2, and every subscription over a few thousand euros is going through procurement review.",
        "We had layoffs last month, so the budget for tools has been cut by about a third.",
    ],
    "low_adoption": [
        "To be honest, most of the team stopped logging in after the onboarding. They went back to their spreadsheets.",
        "We rolled it out to the support team, but nobody really uses the reporting part.",
    ],
    "exec_disengagement": [
        "Our COO used to join these calls, but she has stopped responding to my updates about the tool.",
        "Leadership told me this isn't a priority anymore, so I can't get anyone senior to the QBR.",
    ],
}
DISTRACTOR_LINES = {
    "competitor_mention": "We looked at {comp} last year and picked you, and I'm still glad we did.",
    "champion_departure": "Our previous admin left last year, but I've owned this for twelve months now and it's going well.",
    "pricing_complaint": "Price was a discussion two years ago, but at this point the value is clear to everyone here.",
    "budget_cut": "Budgets are tight everywhere, but this tool is on the protected list for next year.",
}
CSM_OPEN = ["Thanks for making time today. How have the last few weeks been?",
            "Hi! Good to see you again. How are things on your side?"]
CSM_MID = ["Got it, thanks for telling me.", "Okay, that's helpful context.",
           "Understood. Anything else on your mind?", "Let me note that down.",
           "Makes sense. Let's also look at the new dashboard release."]
CSM_CLOSE = ["Great, I'll send the recording and the notes afterwards.",
             "Thanks, I'll follow up by email with next steps."]
CUST_NEUTRAL = ["Pretty busy, we're onboarding two new hires this month.",
                "The weekly export has been really useful for our Monday meeting.",
                "Can you remind me how the permissions work for the new workspace?",
                "Sounds good, send it over.",
                "The integration with our helpdesk has been stable since the last update."]
TITLES = ["Monthly check-in", "QBR", "Renewal prep", "Support follow-up", "Feature walkthrough"]


def messy(name: str, rng: random.Random) -> str:
    """Billing system spells names differently than the CRM (stretch goal: show the matching step)."""
    variants = [name.upper(), f"{name} GmbH", f"{name} GmbH & Co. KG",
                name.replace("ß", "ss").replace("ü", "ue").replace("ö", "oe").replace("ä", "ae"),
                name.replace("&", "und"), f"{name.split()[0]} Group"]
    return rng.choice(variants)


def fmt_turn(name, label, text):
    return f"{name} ({label}): {text}"


def template_transcript(rng, contact, role, company, cust_lines):
    cust_label = f"{role}, {company}"
    csm_label = f"{VENDOR} CSM"
    turns = [fmt_turn(CSM, csm_label, rng.choice(CSM_OPEN)),
             fmt_turn(contact, cust_label, rng.choice(CUST_NEUTRAL))]
    lines = cust_lines + rng.sample(CUST_NEUTRAL, 2)
    rng.shuffle(lines)
    for line in lines:
        turns.append(fmt_turn(CSM, csm_label, rng.choice(CSM_MID)))
        turns.append(fmt_turn(contact, cust_label, line))
    turns.append(fmt_turn(CSM, csm_label, rng.choice(CSM_CLOSE)))
    return "\n".join(turns)


def llm_transcript(spec):
    """Ask the LLM to write a natural call around the required lines; keep it only if every line survives verbatim."""
    required = "\n".join(f"- {l}" for l in spec["cust_lines"]) or "- (none: this is an uneventful, positive call)"
    prompt = (
        f"Write a realistic transcript of a {spec['title']} call between {CSM} (CSM at {VENDOR}, a B2B SaaS tool) "
        f"and {spec['contact']} ({spec['role']} at {spec['company']}).\n"
        f"Format every turn on its own line exactly as:\n"
        f"{CSM} ({VENDOR} CSM): text\n{spec['contact']} ({spec['role']}, {spec['company']}): text\n"
        f"Write 14-22 turns about ordinary topics (features, support tickets, workflows).\n"
        f"The customer must say each of these lines VERBATIM, word for word:\n{required}\n"
        f"Do not add any other complaints, risks, budget issues, competitor names, departures or concerns."
    )
    out = llm.chat_text("You write realistic, plain business call transcripts. No markdown.", prompt)
    if all(l in out for l in spec["cust_lines"]):
        return out.strip()
    return None


def generate(seed: int = 7, llm_transcripts: bool = False, n_in_window: int = 22):
    rng = random.Random(seed)
    con = db.reset()
    today = dt.date.today()
    profiles = ["healthy"] * 12 + ["watch"] * 9 + ["at_risk"] * 9
    rng.shuffle(profiles)
    call_specs = []

    for i, (company, prof) in enumerate(zip(COMPANIES, profiles), start=1):
        contact, role = f"{rng.choice(FIRST)} {rng.choice(LAST)}", rng.choice(ROLES)
        seats = rng.randint(10, 120)
        if prof == "at_risk":
            seats_prev = seats + rng.randint(2, max(3, seats // 4))
        elif prof == "watch":
            seats_prev = seats + rng.choice([0, 0, 1, 3])
        else:
            seats_prev = max(5, seats - rng.choice([0, 0, 2, 5]))
        price = rng.choice([29, 35, 39, 45])
        renew_in = rng.randint(4, 90) if i <= n_in_window else rng.randint(95, 300)
        con.execute("INSERT INTO accounts VALUES (?,?,?,?,?,?,?,?)",
                    (i, company, messy(company, rng), rng.choice(INDUSTRIES), rng.randint(50, 200),
                     contact, role, CSM))
        con.execute("INSERT INTO subscriptions VALUES (?,?,?,?,?,?,?)",
                    (i, rng.choice(["Team", "Business"]), seats, seats_prev, price, seats * price,
                     (today + dt.timedelta(days=renew_in)).isoformat()))

        # 90 days of daily active users; decline starts 45 days ago for risky accounts
        base = seats_prev * rng.uniform(0.55, 0.85)
        drop = {"healthy": rng.uniform(-0.10, 0.05), "watch": rng.uniform(0.10, 0.25),
                "at_risk": rng.uniform(0.30, 0.55)}[prof]
        rows = []
        for d in range(90):
            day = today - dt.timedelta(days=89 - d)
            factor = 1 - drop * ((d - 45) / 44) if d >= 45 else 1.0
            weekend = 0.45 if day.weekday() >= 5 else 1.0
            rows.append((i, day.isoformat(), max(0, round(base * factor * weekend * rng.uniform(0.9, 1.1)))))
        con.executemany("INSERT INTO usage VALUES (?,?,?)", rows)

        # calls and planted signals
        n_sig = {"healthy": 0, "watch": 1, "at_risk": rng.randint(2, 3)}[prof]
        types = rng.sample(list(SIGNAL_TYPES), n_sig)
        n_calls = max(rng.randint(1, 3), 2 if prof == "at_risk" else 1)
        dates = sorted(rng.sample(range(3, 60), n_calls))
        calls = [{"account_id": i, "company": company, "contact": contact, "role": role,
                  "date": (today - dt.timedelta(days=d)).isoformat(), "title": rng.choice(TITLES),
                  "signals": [], "distractors": []} for d in dates]
        for t in types:
            rng.choice(calls)["signals"].append(t)
        fill = dict(co=company, nxt=f"{rng.choice(FIRST)} {rng.choice(LAST)}",
                    comp=rng.choice(COMPETITORS), seats=seats_prev)
        for c in calls:
            options = [t for t in DISTRACTOR_LINES if t not in c["signals"]]
            if rng.random() < 0.35 and options:
                c["distractors"].append(rng.choice(options))
            c["sig_lines"] = [(t, rng.choice(SIGNAL_LINES[t]).format(**fill)) for t in c["signals"]]
            c["dis_lines"] = [(t, DISTRACTOR_LINES[t].format(**fill)) for t in c["distractors"]]
            c["cust_lines"] = [l for _, l in c["sig_lines"] + c["dis_lines"]]
            call_specs.append(c)

    def render(spec):
        if llm_transcripts and llm.enabled():
            try:
                out = llm_transcript(spec)
                if out:
                    return out
            except Exception as e:  # noqa: BLE001 - fall back on any API error
                print("LLM transcript failed, using template:", e)
        return template_transcript(random.Random(spec["date"] + spec["company"]),
                                   spec["contact"], spec["role"], spec["company"], spec["cust_lines"])

    with ThreadPoolExecutor(max_workers=8) as pool:
        transcripts = list(pool.map(render, call_specs))

    for call_id, (spec, text) in enumerate(zip(call_specs, transcripts), start=1):
        con.execute("INSERT INTO calls VALUES (?,?,?,?,?)",
                    (call_id, spec["account_id"], spec["date"], spec["title"], text))
        for t, line in spec["sig_lines"]:
            con.execute("INSERT INTO planted VALUES (?,?,?,0)", (call_id, t, line))
        for t, line in spec["dis_lines"]:
            con.execute("INSERT INTO planted VALUES (?,?,?,1)", (call_id, t, line))
    con.commit()
    n_planted = con.execute("SELECT COUNT(*) FROM planted WHERE is_distractor=0").fetchone()[0]
    print(f"Generated {len(COMPANIES)} accounts, {len(call_specs)} calls, {n_planted} planted signals.")
    return con


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--seed", type=int, default=7)
    ap.add_argument("--llm-transcripts", action="store_true", help="have the LLM write natural transcripts")
    a = ap.parse_args()
    generate(a.seed, a.llm_transcripts)
