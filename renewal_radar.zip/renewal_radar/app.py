"""The one screen: ranked renewals -> click -> evidence-linked brief.  Run: streamlit run app.py"""
import html
import re

import altair as alt
import pandas as pd
import streamlit as st

import brief as brief_mod
import db
import llm
from evaluate import evaluate
from scoring import score_all
from taxonomy import LABELS

st.set_page_config(page_title="Renewal Radar", page_icon="📡", layout="wide")

RED, AMBER, GREEN, BLUE = "#C93B3B", "#D98E04", "#2E8B57", "#4A6FA5"
BAND_COLOR = {"High": RED, "Medium": AMBER, "Low": GREEN}
BAND_DOT = {"High": "🔴", "Medium": "🟠", "Low": "🟢"}

st.markdown(f"""
<style>
  .block-container {{padding-top: 3.2rem; max-width: 1400px;}}
  .rr-title {{font-size: 1.7rem; font-weight: 750; letter-spacing: -0.02em; margin: 0;}}
  .rr-sub {{opacity: .65; margin: 0 0 1rem 0;}}
  .rr-pill {{display:inline-block; padding:2px 11px; border-radius:999px; font-weight:650;
             font-size:.78rem; color:#fff; vertical-align: 4px; margin-left: 8px;}}
  .rr-acct {{font-size:1.35rem; font-weight:700; margin:0;}}
  .rr-meta {{font-size:.8rem; opacity:.65;}}
  .rr-brief p {{font-size:1.02rem; line-height:1.65; margin:0 0 .45rem 0;}}
  .rr-next {{border-radius:8px; padding:10px 14px; margin-top:.6rem; background:rgba(74,111,165,.10);
             border:1px solid rgba(74,111,165,.35);}}
  .rr-cite {{display:inline-block; font-size:.68rem; font-weight:700; padding:0 6px; border-radius:4px;
             background:{BLUE}; color:#fff !important; text-decoration:none !important; margin-left:3px;
             vertical-align:2px;}}
  .rr-ev {{border:1px solid rgba(128,128,128,.25); border-left:4px solid {RED}; border-radius:8px;
           padding:9px 13px; margin-bottom:9px; scroll-margin-top: 80px;}}
  .rr-ev.metric {{border-left-color:{BLUE};}}
  .rr-ev .id {{font-weight:700; font-size:.72rem; color:{BLUE}; margin-right:6px;}}
  .rr-ev .lbl {{font-weight:650; font-size:.85rem;}}
  .rr-quote {{font-style:italic; margin:5px 0 3px 0; line-height:1.5;}}
  .rr-tx {{font-size:.86rem; line-height:1.6;}}
  .rr-tx .csm {{opacity:.6;}}
  mark {{background:#FFE58F; color:#222; padding:0 2px; border-radius:2px;}}
</style>
""", unsafe_allow_html=True)


con = db.connect()  # cheap; not cached so a regenerated DB is picked up

# ---------------------------------------------------------------- sidebar
with st.sidebar:
    st.markdown("### Filters")
    window = st.slider("Renewing within (days)", 14, 90, 90, step=7)
    bands = st.multiselect("Risk", ["High", "Medium", "Low"], default=["High", "Medium", "Low"])
    st.divider()
    st.caption(f"AI mode: **{'LLM · ' + llm.MODEL if llm.enabled() else 'offline rules'}**")
    st.caption("Synthetic data only. All companies and people are fictional.")

accounts = [a for a in score_all(con, window_days=window) if a["band"] in bands]

st.markdown('<p class="rr-title">📡 Renewal Radar</p>', unsafe_allow_html=True)
st.markdown(f'<p class="rr-sub">Lena\'s renewals in the next {window} days, ranked by risk. '
            f'Every flag links to the call quote or usage change behind it.</p>', unsafe_allow_html=True)

tab_list, tab_acc = st.tabs(["Renewals", "Is the AI right?"])

# ---------------------------------------------------------------- tab 1
with tab_list:
    high = [a for a in accounts if a["band"] == "High"]
    k1, k2, k3, k4 = st.columns(4)
    k1.metric("Renewing", len(accounts))
    k2.metric("High risk", len(high))
    k3.metric("ARR at risk", f"€{sum(a['arr'] for a in high):,.0f}")
    k4.metric("Call signals found", sum(len(a["signals"]) for a in accounts))

    if not accounts:
        st.info("No renewals match these filters.")
        st.stop()

    df = pd.DataFrame([{
        "Account": f'{BAND_DOT[a["band"]]} {a["crm_name"]}',
        "Risk": a["score"],
        "Renews in": f"{a['days_to_renewal']} d",
        "ARR": a["arr"],
        "Usage": a["usage_pct"] * 100,
        "Signals": len(a["signals"]),
    } for a in accounts])

    left, right = st.columns([1.2, 1.25], gap="large")
    with left:
        st.markdown("**Ranked renewals** · click a row")
        event = st.dataframe(
            df, hide_index=True, width="stretch", height=min(640, 38 + 35 * len(df)),
            on_select="rerun", selection_mode="single-row", key="table",
            column_config={
                "Risk": st.column_config.ProgressColumn(min_value=0, max_value=100, format="%d", width="small"),
                "ARR": st.column_config.NumberColumn(format="euro"),
                "Usage": st.column_config.NumberColumn(format="%+.0f%%", help="Last 14 days vs. baseline"),
                "Signals": st.column_config.NumberColumn(help="Risk signals found in calls"),
            })
        rows = event.selection.rows if event and event.selection else []
        acc = accounts[rows[0]] if rows else accounts[0]

    with right:
        payload, source = brief_mod.get_brief(con, acc)
        ev_by_id = {e["id"]: e for e in payload["evidence"]}
        pill = f'<span class="rr-pill" style="background:{BAND_COLOR[acc["band"]]}">{acc["band"]} · {acc["score"]}</span>'
        st.markdown(f'<p class="rr-acct">{html.escape(acc["crm_name"])}{pill}</p>'
                    f'<p class="rr-meta">Renews {acc["renewal_date"]} ({acc["days_to_renewal"]} days) · '
                    f'€{acc["arr"]:,.0f} ARR · {acc["seats"]} seats · {acc["industry"]} · '
                    f'contact {html.escape(acc["contact_name"])}, {html.escape(acc["contact_role"])}</p>',
                    unsafe_allow_html=True)

        def cites(ids):
            return "".join(f'<a class="rr-cite" href="#ev-{i}">{i}</a>' for i in ids if i in ev_by_id)

        body = "".join(f"<p>{html.escape(s['text'])}{cites(s['evidence'])}</p>" for s in payload["sentences"])
        nxt = payload["next_step"]
        st.markdown(f'<div class="rr-brief">{body}<div class="rr-next"><b>Next step:</b> '
                    f'{html.escape(nxt["text"])}{cites(nxt["evidence"])}</div></div>', unsafe_allow_html=True)
        st.caption(f"Brief written by {'the LLM' if source == 'llm' else 'template (offline)'}; "
                   "it may only use the evidence below.")

        c_ev, c_chart = st.columns([1.1, 1], gap="medium")
        with c_ev:
            st.markdown("**Evidence**")
            for e in payload["evidence"]:
                if e["kind"] == "signal":
                    st.markdown(
                        f'<div class="rr-ev" id="ev-{e["id"]}"><span class="id">{e["id"]}</span>'
                        f'<span class="lbl">{html.escape(e["label"])}</span>'
                        f'<div class="rr-quote">“{html.escape(e["quote"])}”</div>'
                        f'<div class="rr-meta">{html.escape(e["speaker"])} · {html.escape(e["call_title"])} · '
                        f'{e["call_date"]}</div></div>', unsafe_allow_html=True)
                else:
                    st.markdown(f'<div class="rr-ev metric" id="ev-{e["id"]}"><span class="id">{e["id"]}</span>'
                                f'{html.escape(e["text"])}</div>', unsafe_allow_html=True)
        with c_chart:
            st.markdown("**Daily active users**")
            u = pd.read_sql("SELECT day, active_users FROM usage WHERE account_id=? ORDER BY day",
                            con, params=(acc["id"],))
            u["day"] = pd.to_datetime(u["day"])
            u["7-day avg"] = u["active_users"].rolling(7, min_periods=7).mean()
            color = RED if acc["usage_pct"] <= -0.08 else BLUE
            raw = alt.Chart(u).mark_line(opacity=0.25, color=color).encode(
                x=alt.X("day:T", title=None), y=alt.Y("active_users:Q", title=None))
            avg = alt.Chart(u).mark_line(strokeWidth=2.5, color=color).encode(x="day:T", y="7-day avg:Q")
            seats = alt.Chart(pd.DataFrame({"y": [acc["seats"]]})).mark_rule(strokeDash=[4, 4], opacity=.5).encode(y="y:Q")
            st.altair_chart((raw + avg + seats).properties(height=190), width="stretch")
            st.caption(f"{acc['usage_pct']:+.0%} last 14 days vs. baseline · dashed line = paid seats")

            st.markdown("**Why this score**")
            comp = pd.DataFrame({"Part": list(acc["components"]), "Points": list(acc["components"].values())})
            bars = alt.Chart(comp).mark_bar(color=BAND_COLOR[acc["band"]], cornerRadiusEnd=3).encode(
                x=alt.X("Points:Q", scale=alt.Scale(domain=[0, 45]), title=None),
                y=alt.Y("Part:N", sort=None, title=None))
            text = bars.mark_text(align="left", dx=4, color="gray").encode(text="Points:Q")
            st.altair_chart((bars + text).properties(height=140), width="stretch")

        calls = con.execute("SELECT * FROM calls WHERE account_id=? ORDER BY call_date DESC", (acc["id"],)).fetchall()
        with st.expander(f"Call transcripts ({len(calls)}) · flagged quotes highlighted"):
            quotes = [e["quote"] for e in payload["evidence"] if e["kind"] == "signal"]
            for c in calls:
                st.markdown(f"**{c['title']}** · {c['call_date']}")
                lines = []
                for line in c["transcript"].splitlines():
                    esc = html.escape(line)
                    for q in quotes:
                        esc = re.sub(re.escape(html.escape(q)), lambda m: f"<mark>{m.group(0)}</mark>", esc)
                    cls = "csm" if "CSM)" in line else ""
                    lines.append(f'<div class="{cls}">{esc}</div>')
                st.markdown(f'<div class="rr-tx">{"".join(lines)}</div>', unsafe_allow_html=True)
                st.divider()
        if st.button("↻ Regenerate brief"):
            brief_mod.get_brief(con, acc, force=True)
            st.rerun()

# ---------------------------------------------------------------- tab 2
with tab_acc:
    r = evaluate(con)
    st.markdown(f"We planted **{r['planted']} risk signals** in **{r['calls']} synthetic calls**, plus "
                f"**{r['decoys']} decoys**: lines that sound risky but aren't (*\"we looked at a competitor last "
                f"year and picked you\"*). Here's how the extractor did "
                f"({'LLM · ' + llm.MODEL if r['source'] == 'llm' else 'offline keyword rules'}).")
    m1, m2, m3, m4 = st.columns(4)
    m1.metric("Recall", f"{r['recall']:.0%}", help="Share of planted signals found")
    m2.metric("Precision", f"{r['precision']:.0%}", help="Share of flags that were real")
    m3.metric("Decoys resisted", f"{r['decoys_resisted']}/{r['decoys']}")
    m4.metric("F1", f"{r['f1']:.0%}")
    st.dataframe(pd.DataFrame(r["per_type"]), hide_index=True, width="stretch")
    a, b = st.columns(2)
    with a:
        st.markdown(f"**Missed ({len(r['misses'])})**")
        st.dataframe(pd.DataFrame(r["misses"]) if r["misses"] else pd.DataFrame({"": ["None 🎉"]}),
                     hide_index=True, width="stretch")
    with b:
        st.markdown(f"**False alarms ({len(r['false_alarm_rows'])})**")
        st.dataframe(pd.DataFrame(r["false_alarm_rows"]) if r["false_alarm_rows"] else pd.DataFrame({"": ["None 🎉"]}),
                     hide_index=True, width="stretch")
