import sqlite3
from pathlib import Path

DB_PATH = Path(__file__).parent / "renewal.db"

SCHEMA = """
CREATE TABLE accounts (
    id INTEGER PRIMARY KEY,
    crm_name TEXT, billing_name TEXT, industry TEXT, employees INTEGER,
    contact_name TEXT, contact_role TEXT, csm TEXT
);
CREATE TABLE subscriptions (
    account_id INTEGER PRIMARY KEY, plan TEXT, seats INTEGER, seats_prev INTEGER,
    price_per_seat REAL, mrr REAL, renewal_date TEXT
);
CREATE TABLE usage (account_id INTEGER, day TEXT, active_users INTEGER);
CREATE TABLE calls (id INTEGER PRIMARY KEY, account_id INTEGER, call_date TEXT, title TEXT, transcript TEXT);
-- ground truth: what we planted (is_distractor=1 means a look-alike that is NOT a risk)
CREATE TABLE planted (call_id INTEGER, signal_type TEXT, line TEXT, is_distractor INTEGER);
CREATE TABLE signals (
    id INTEGER PRIMARY KEY AUTOINCREMENT, call_id INTEGER, account_id INTEGER,
    signal_type TEXT, speaker TEXT, confidence REAL, quote TEXT, source TEXT
);
CREATE TABLE briefs (account_id INTEGER PRIMARY KEY, payload TEXT, source TEXT, created_at TEXT);
"""


def connect():
    con = sqlite3.connect(DB_PATH, check_same_thread=False)
    con.row_factory = sqlite3.Row
    return con


def reset():
    if DB_PATH.exists():
        DB_PATH.unlink()
    con = connect()
    con.executescript(SCHEMA)
    con.commit()
    return con
