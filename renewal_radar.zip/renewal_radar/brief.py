"""Renewal brief. The LLM sees ONLY a numbered evidence list and must cite an evidence id in every
sentence; any sentence with a missing or unknown citation fails validation and we fall back to a template."""
import datetime as dt
import json

import db
import llm
from taxonomy import SIGNAL_TYPES

SCHEMA = {
    "type": "object", "additionalProperties": False, "required": ["sentences", "next_step"],
    "properties": {
        "sentences": {"type": "array", "items": {
            "type": "object", "additionalProperties": False, "required": ["text", "evidence"],
            "properties": {"text": {"type": "string"}, "evidence": {"type": "array", "items": {"type": "string"}}}}},
        "next_step": {"type": "object", "additionalProperties": False, "required": ["text", "evidence"],
                      "properties": {"text": {"type": "string"}, "evidence": {"type": "array", "items": {"type": "string"}}}},
    },
}

SYSTEM = (
    "You write renewal-prep briefs for a customer success manager. Use ONLY the numbered evidence. "
    "Write 2-4 short sentences explaining the renewal risk (or why the account looks healthy), then one concrete next step. "
    "Every sentence and the next step must cite at least one evidence id like E1. Never invent facts, numbers or names "
    "that are not in the evidence. Plain, direct language."
)


def build_evidence(acc):
    ev = []
    sigs = sorted(acc["signals"], key=lambda s: -SIGNAL_TYPES[s["signal_type"]]["weight"] * s["confidence"])
    for s in sigs:
        ev.append({"id": f"E{len(ev) + 1}", "kind": "signal", "signal_type": s["signal_type"],
                   "label": SIGNAL_TYPES[s["signal_type"]]["label"], "quote": s["quote"], "speaker": s["speaker"],
                   "call_date": s["call_date"], "call_title": s["title"], "call_id": s["call_id"],
                   "text": f'{SIGNAL_TYPES[s["signal_type"]]["label"]}: "{s["quote"]}" ({s["speaker"]}, {s["title"]} on {s["call_date"]})'})
    if acc["usage_pct"] <= -0.08:
        ev.append({"id": f"E{len(ev) + 1}", "kind": "usage",
                   "text": f"Daily active users are down {abs(acc['usage_pct']):.0%} over the last 14 days vs. the earlier baseline."})
    elif acc["usage_pct"] >= 0.03:
        ev.append({"id": f"E{len(ev) + 1}", "kind": "usage",
                   "text": f"Daily active users are up {acc['usage_pct']:.0%} over the last 14 days vs. the earlier baseline."})
    if acc["seats_prev"] > acc["seats"]:
        ev.append({"id": f"E{len(ev) + 1}", "kind": "seats",
                   "text": f"Seats were reduced from {acc['seats_prev']} to {acc['seats']}."})
    ev.append({"id": f"E{len(ev) + 1}", "kind": "renewal",
               "text": f"Renews on {acc['renewal_date']} ({acc['days_to_renewal']} days), worth €{acc['arr']:,.0f} ARR."})
    return ev


def validate(payload, ids):
    items = payload["sentences"] + [payload["next_step"]]
    return bool(payload["sentences"]) and all(
        it["text"].strip() and it["evidence"] and set(it["evidence"]) <= ids for it in items)


def template_brief(acc, ev):
    by_kind = {e["kind"]: e for e in ev}
    sigs = [e for e in ev if e["kind"] == "signal"]
    renewal = by_kind["renewal"]
    sentences = [{"text": f"{acc['crm_name']} renews in {acc['days_to_renewal']} days and is rated {acc['band'].lower()} risk.",
                  "evidence": [renewal["id"]]}]
    for e in sigs[:3]:
        sentences.append({"text": f"{e['label']} flagged by {e['speaker']} in the {e['call_title']} on {e['call_date']}.",
                          "evidence": [e["id"]]})
    if "usage" in by_kind:
        sentences.append({"text": by_kind["usage"]["text"], "evidence": [by_kind["usage"]["id"]]})
    if "seats" in by_kind:
        sentences.append({"text": by_kind["seats"]["text"], "evidence": [by_kind["seats"]["id"]]})
    if sigs:
        nxt = {"text": SIGNAL_TYPES[sigs[0]["signal_type"]]["next_step"], "evidence": [sigs[0]["id"]]}
    elif "usage" in by_kind and acc["usage_pct"] < 0:
        nxt = {"text": "Ask which workflows the team stopped using and offer a short re-onboarding.",
               "evidence": [by_kind["usage"]["id"]]}
    else:
        nxt = {"text": "Send the renewal quote early and ask for a reference or case study.", "evidence": [renewal["id"]]}
    return {"sentences": sentences, "next_step": nxt}


def make_brief(acc):
    ev = build_evidence(acc)
    if llm.enabled():
        try:
            user = f"Account: {acc['crm_name']} (risk score {acc['score']}/100, {acc['band']})\nEvidence:\n" + \
                   "\n".join(f"{e['id']}: {e['text']}" for e in ev)
            payload = llm.chat_json(SYSTEM, user, SCHEMA, "renewal_brief", temperature=0.2)
            if validate(payload, {e["id"] for e in ev}):
                return {"evidence": ev, **payload}, "llm"
        except Exception as e:  # noqa: BLE001
            print("brief LLM failed:", e)
    return {"evidence": ev, **template_brief(acc, ev)}, "template"


def get_brief(con, acc, force=False):
    row = con.execute("SELECT payload, source FROM briefs WHERE account_id=?", (acc["id"],)).fetchone()
    if row and not force:
        return json.loads(row["payload"]), row["source"]
    payload, source = make_brief(acc)
    con.execute("INSERT OR REPLACE INTO briefs VALUES (?,?,?,?)",
                (acc["id"], json.dumps(payload), source, dt.datetime.now().isoformat(timespec="seconds")))
    con.commit()
    return payload, source


def run_all(con=None, accounts=None):
    from scoring import score_all
    con = con or db.connect()
    con.execute("DELETE FROM briefs")
    for acc in accounts or score_all(con, window_days=90):
        get_brief(con, acc, force=True)
    print("Briefs written.")
